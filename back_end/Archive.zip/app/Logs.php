<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Logs extends Model
{
    protected $table = 'logs';
    public $incrementing = false;
    protected $primaryKey = 'log_id';
}
